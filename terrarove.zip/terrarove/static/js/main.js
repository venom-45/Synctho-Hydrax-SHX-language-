/* ============================================================
   TERRAROVE REGISTER — Main Frontend Script
   ============================================================ */

(function () {
  'use strict';

  /* ---------- Utilities ---------- */
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return {
        '&': '&amp;', '<': '&lt;', '>': '&gt;',
        '"': '&quot;', "'": '&#39;'
      }[c];
    });
  }

  function instagramHandle(raw) {
    let v = String(raw || '').trim();
    v = v.replace(/^@/, '');
    v = v.replace(/^https?:\/\/(www\.)?instagram\.com\//i, '');
    v = v.replace(/\/+$/, '');
    return v;
  }

  function padNo(n) { return String(n || 0).padStart(3, '0'); }

  function showNotification(el, type, message, timeout) {
    if (!el) return;
    el.textContent = message;
    el.classList.remove('success', 'error');
    el.classList.add(type);
    clearTimeout(el._hideTimer);
    el._hideTimer = setTimeout(function () {
      el.classList.remove('success', 'error');
    }, timeout || 6000);
  }

  /* ---------- Ripple ---------- */
  function initRipple() {
    document.addEventListener('pointerdown', function (e) {
      const btn = e.target.closest('.btn');
      if (!btn || btn.disabled) return;
      const rect = btn.getBoundingClientRect();
      btn.style.setProperty('--x', (e.clientX - rect.left) + 'px');
      btn.style.setProperty('--y', (e.clientY - rect.top) + 'px');
    }, { passive: true });
  }

  /* ---------- Nations ---------- */
  const nationsGrid = document.getElementById('nationsGrid');
  const nationCountLabel = document.getElementById('nationCountLabel');

  async function loadNations() {
    if (!nationsGrid) return;
    try {
      const res = await fetch('/api/nations', { headers: { Accept: 'application/json' } });
      if (!res.ok) throw new Error('Failed to fetch nations');
      const nations = await res.json();
      renderNations(nations);
    } catch (err) {
      console.error('[Terrarove] nations load error:', err);
      nationsGrid.innerHTML = '<div class="empty-note">⚠️ Could not load the nations list right now.</div>';
    }
  }

  function renderNations(nations) {
    if (!Array.isArray(nations)) nations = [];
    if (nationCountLabel) nationCountLabel.textContent = nations.length;

    // ⭐ Update the hero text dynamically
    updateHeroText(nations);

    if (nations.length === 0) {
      nationsGrid.innerHTML = '<div class="empty-note">🌱 No nation has been recognized yet — be the first to found one.</div>';
      return;
    }

    const sorted = nations.slice().sort(function (a, b) {
      return (a.registryNo || 0) - (b.registryNo || 0);
    });

    nationsGrid.innerHTML = sorted.map(function (n, index) {
      const handle = instagramHandle(n.instagram);
      const igBlock = handle
        ? '<div class="nation-ig"><a href="https://instagram.com/' + encodeURIComponent(handle) +
          '" target="_blank" rel="noopener noreferrer">@' + escapeHtml(handle) + '</a></div>'
        : '';

      return (
        '<article class="nation-card" style="animation-delay:' + Math.min(index * 40, 400) + 'ms">' +
          '<img class="nation-flag" src="' + escapeHtml(n.flag) + '" alt="Flag of ' + escapeHtml(n.name) + '" loading="lazy">' +
          '<div class="nation-info">' +
            '<div>' +
              '<div class="nation-name">' + escapeHtml(n.name) + '</div>' +
              '<div class="nation-reg">Filed as No. ' + padNo(n.registryNo) + '</div>' +
              igBlock +
            '</div>' +
            '<div class="seal-badge" aria-label="Recognized">RECOG&shy;NIZED</div>' +
          '</div>' +
        '</article>'
      );
    }).join('');
  }

  /* ---------- Dynamic Hero Text ---------- */
  function updateHeroText(nations) {
    const headline = document.getElementById('heroHeadline');
    const subtext = document.getElementById('heroSubtext');
    if (!headline || !subtext) return;

    const count = nations.length;
    const names = nations
      .slice()
      .sort((a, b) => (a.registryNo || 0) - (b.registryNo || 0))
      .map(n => n.name)
      .filter(Boolean);

    // ---- Headline ----
    const numberWords = {
      0: 'No flags raised.',
      1: 'One flag raised.',
      2: 'Two flags raised.',
      3: 'Three flags raised.',
      4: 'Four flags raised.',
      5: 'Five flags raised.',
      6: 'Six flags raised.',
      7: 'Seven flags raised.',
      8: 'Eight flags raised.',
      9: 'Nine flags raised.',
      10: 'Ten flags raised.'
    };

    if (count === 0) {
      headline.textContent = 'No flags raised.';
    } else if (numberWords[count]) {
      headline.textContent = numberWords[count];
    } else {
      headline.textContent = count + ' flags raised.';
    }

    // ---- Subtext ----
    let sub = 'Terrarove is a blank canvas. ';

    if (count === 0) {
      sub += 'No nation has claimed a territory yet — be the first to found one.';
    } else if (count === 1) {
      sub += names[0] + ' claimed the first territory. Everywhere else is unclaimed — ready for your nation, your flag, your story.';
    } else if (count === 2) {
      sub += names[0] + ' and ' + names[1] + ' claimed the first territories. Everywhere else is unclaimed — ready for your nation, your flag, your story.';
    } else if (count === 3) {
      sub += names[0] + ', ' + names[1] + ' and ' + names[2] + ' claimed the first territories. Everywhere else is unclaimed — ready for your nation, your flag, your story.';
    } else {
      const firstTwo = names.slice(0, 2).join(', ');
      const rest = count - 2;
      sub += firstTwo + ' and ' + rest + ' more nation' + (rest === 1 ? '' : 's') + ' have claimed their ground. There\u2019s still room on the map — found yours.';
    }

    subtext.textContent = sub;
  }

  /* ---------- Map ---------- */
  const worldMapImg = document.getElementById('worldMapImg');

  async function loadMap() {
    if (!worldMapImg) return;
    try {
      const res = await fetch('/api/map', { headers: { Accept: 'application/json' } });
      if (!res.ok) throw new Error('Failed to fetch map');
      const data = await res.json();
      if (data && data.path) worldMapImg.src = data.path;
    } catch (err) {
      console.error('[Terrarove] map load error:', err);
    }
  }

  /* ---------- Apply form ---------- */
  function initApplyForm() {
    const applyForm = document.getElementById('applyForm');
    if (!applyForm) return;

    const countryInput = document.getElementById('countryName');
    const flagFileInput = document.getElementById('flagFile');
    const flagPreview = document.getElementById('flagPreview');
    const confirmNote = document.getElementById('confirmNote');
    const errorNote = document.getElementById('errorNote');
    const termsCheck = document.getElementById('termsCheck');
    const submitBtn = document.getElementById('submitBtn');

    const MAX_FLAG_SIZE = 3 * 1024 * 1024;

    /* Lock submit until Terms are accepted */
    function syncSubmitState() {
      if (!submitBtn || !termsCheck) return;
      submitBtn.disabled = !termsCheck.checked;
      submitBtn.title = termsCheck.checked ? '' : 'You must agree to the Terms of Service first';
    }
    if (termsCheck) {
      termsCheck.addEventListener('change', syncSubmitState);
      syncSubmitState();
    }

    /* Live flag preview */
    if (flagFileInput && flagPreview) {
      flagFileInput.addEventListener('change', function () {
        const file = flagFileInput.files && flagFileInput.files[0];
        if (!file) {
          flagPreview.classList.remove('visible');
          flagPreview.removeAttribute('src');
          return;
        }
        if (!file.type.startsWith('image/')) {
          showNotification(errorNote, 'error', '🚫 Please choose an image file (PNG, JPG, WEBP).');
          flagFileInput.value = '';
          return;
        }
        if (file.size > MAX_FLAG_SIZE) {
          showNotification(errorNote, 'error', '📦 That image is larger than 3 MB — please pick a smaller one.');
          flagFileInput.value = '';
          return;
        }
        const reader = new FileReader();
        reader.onload = function (e) {
          flagPreview.src = e.target.result;
          flagPreview.classList.add('visible');
        };
        reader.readAsDataURL(file);
      });
    }

    /* Submit */
    applyForm.addEventListener('submit', async function (e) {
      e.preventDefault();

      if (confirmNote) confirmNote.classList.remove('success', 'error');
      if (errorNote) errorNote.classList.remove('success', 'error');

      const name = countryInput ? countryInput.value.trim() : '';
      const file = flagFileInput && flagFileInput.files && flagFileInput.files[0];

      if (!name) {
        showNotification(errorNote, 'error', '✏️ Your country needs a name before it can be filed.');
        countryInput && countryInput.focus();
        return;
      }
      if (!file) {
        showNotification(errorNote, 'error', '🏴 Please upload a flag image for your nation.');
        return;
      }
      if (file.size > MAX_FLAG_SIZE) {
        showNotification(errorNote, 'error', '📦 Flag image must be under 3 MB.');
        return;
      }
      if (termsCheck && !termsCheck.checked) {
        showNotification(errorNote, 'error', '📜 You must agree to the Terms of Service before filing.');
        termsCheck.focus();
        return;
      }

      const originalLabel = submitBtn ? submitBtn.textContent : '';
      if (submitBtn) {
        submitBtn.disabled = true;
        submitBtn.textContent = '⏳ Filing…';
      }

      try {
        const formData = new FormData(applyForm);
        const res = await fetch('/api/apply', {
          method: 'POST',
          body: formData,
          headers: { Accept: 'application/json' }
        });
        const data = await res.json().catch(function () { return {}; });

        if (!res.ok) throw new Error(data.error || 'Submission failed. Please try again.');

        showNotification(confirmNote, 'success', '✅ Your filing has been received. The Chancellery will review it.');

        applyForm.reset();
        if (flagPreview) {
          flagPreview.classList.remove('visible');
          flagPreview.removeAttribute('src');
        }
        syncSubmitState();
      } catch (err) {
        console.error('[Terrarove] apply error:', err);
        showNotification(errorNote, 'error', '⚠️ ' + (err.message || 'Something went wrong.'));
      } finally {
        if (submitBtn) {
          submitBtn.textContent = originalLabel || 'Submit for recognition';
          syncSubmitState();
        }
      }
    });
  }

  /* ---------- Smooth scroll ---------- */
  function initSmoothScroll() {
    document.querySelectorAll('a[href^="#"]').forEach(function (link) {
      link.addEventListener('click', function (e) {
        const href = link.getAttribute('href');
        if (!href || href === '#' || href.length < 2) return;
        const target = document.querySelector(href);
        if (!target) return;
        e.preventDefault();
        const y = target.getBoundingClientRect().top + window.pageYOffset - 80;
        window.scrollTo({ top: y, behavior: 'smooth' });
        if (history.replaceState) history.replaceState(null, '', href);
      });
    });
  }

  /* ---------- Header shadow ---------- */
  function initHeaderScroll() {
    const header = document.querySelector('.site-header');
    if (!header) return;
    let lastY = 0;
    function onScroll() {
      const y = window.scrollY;
      if (y > 8 && lastY <= 8) header.style.boxShadow = '0 8px 24px -12px rgba(0,0,0,0.6)';
      else if (y <= 8 && lastY > 8) header.style.boxShadow = 'none';
      lastY = y;
    }
    window.addEventListener('scroll', onScroll, { passive: true });
  }

  /* ---------- Init ---------- */
  function init() {
    initRipple();
    initApplyForm();
    initSmoothScroll();
    initHeaderScroll();
    loadNations();
    loadMap();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();