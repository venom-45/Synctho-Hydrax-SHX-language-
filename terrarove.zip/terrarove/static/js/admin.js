/* ============================================================
   TERRAROVE REGISTER — Admin (Chancellery) Script
   Handles: seal-code gate, pending filings, decisions, map swap
   ============================================================ */

(function () {
  'use strict';

  /* ----------------------------------------------------------
     UTILITIES
     ---------------------------------------------------------- */
  function escapeHtml(str) {
    return String(str == null ? '' : str).replace(/[&<>"']/g, function (c) {
      return {
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
      }[c];
    });
  }

  function instagramHandle(raw) {
    let v = String(raw || '').trim();
    v = v.replace(/^@/, '');
    v = v.replace(/^https?:\/\/(www\.)?instagram\.com\//i, '');
    v = v.replace(/\/+$/, '');
    return v;
  }

  function fmtDate(iso) {
    try {
      const d = new Date(iso);
      if (isNaN(d.getTime())) return '';
      return d.toLocaleDateString(undefined, {
        year: 'numeric', month: 'short', day: 'numeric'
      });
    } catch (e) { return ''; }
  }

  /* ----------------------------------------------------------
     RIPPLE (shared with main but duplicated for admin page)
     ---------------------------------------------------------- */
  function initRipple() {
    document.addEventListener('pointerdown', function (e) {
      const btn = e.target.closest('.btn');
      if (!btn || btn.disabled) return;
      const rect = btn.getBoundingClientRect();
      btn.style.setProperty('--x', (e.clientX - rect.left) + 'px');
      btn.style.setProperty('--y', (e.clientY - rect.top) + 'px');
    }, { passive: true });
  }

  /* ----------------------------------------------------------
     STATE
     ---------------------------------------------------------- */
  const STORAGE_KEY = 'terrarove_admin_code';
  let adminCode = sessionStorage.getItem(STORAGE_KEY) || '';

  /* ----------------------------------------------------------
     DOM
     ---------------------------------------------------------- */
  const gateWrap = document.getElementById('gateWrap');
  const gateCode = document.getElementById('gateCode');
  const gateSubmit = document.getElementById('gateSubmit');
  const gateError = document.getElementById('gateError');
  const chancelleryPanel = document.getElementById('chancelleryPanel');
  const pendingList = document.getElementById('pendingList');
  const mapFile = document.getElementById('mapFile');
  const mapConfirmNote = document.getElementById('mapConfirmNote');
  const currentMapThumb = document.getElementById('currentMapThumb');

  /* ----------------------------------------------------------
     NOTIFICATION helper (reuse the .notification styles)
     ---------------------------------------------------------- */
  function notify(el, type, msg, timeout) {
    if (!el) return;
    el.textContent = msg;
    el.classList.remove('success', 'error');
    el.classList.add(type);
    clearTimeout(el._t);
    el._t = setTimeout(function () {
      el.classList.remove('success', 'error');
    }, timeout || 5000);
  }

  /* ----------------------------------------------------------
     1. SEAL-CODE GATE
     ---------------------------------------------------------- */
  async function tryUnlock(code) {
    if (!code) {
      notify(gateError, 'error', 'Please enter a seal-code.');
      return;
    }

    gateSubmit.disabled = true;
    const original = gateSubmit.textContent;
    gateSubmit.textContent = '⏳ Checking…';

    try {
      const res = await fetch('/api/admin/verify', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code: code })
      });

      if (res.ok) {
        adminCode = code;
        sessionStorage.setItem(STORAGE_KEY, code);
        gateWrap.style.display = 'none';
        chancelleryPanel.style.display = 'block';
        gateError.classList.remove('error', 'success');
        loadPending();
        loadMapThumb();
      } else {
        notify(gateError, 'error', '🚫 That seal-code isn\u2019t recognized.');
        gateCode.select();
      }
    } catch (err) {
      console.error('[Terrarove admin] verify error:', err);
      notify(gateError, 'error', '⚠️ Verification failed. Try again.');
    } finally {
      gateSubmit.disabled = false;
      gateSubmit.textContent = original || 'Enter';
    }
  }

  if (gateSubmit) {
    gateSubmit.addEventListener('click', function () {
      tryUnlock((gateCode.value || '').trim());
    });
  }

  if (gateCode) {
    gateCode.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') {
        e.preventDefault();
        tryUnlock((gateCode.value || '').trim());
      }
    });
  }

  /* ----------------------------------------------------------
     2. PENDING FILINGS — list + render
     ---------------------------------------------------------- */
  async function loadPending() {
    if (!pendingList) return;
    pendingList.innerHTML = '<p style="color:var(--text-soft);">Loading…</p>';

    try {
      const res = await fetch('/api/admin/applications', {
        headers: { 'X-Admin-Code': adminCode, Accept: 'application/json' }
      });

      if (res.status === 401) {
        sessionStorage.removeItem(STORAGE_KEY);
        adminCode = '';
        gateWrap.style.display = 'block';
        chancelleryPanel.style.display = 'none';
        notify(gateError, 'error', 'Session expired — please re-enter the seal-code.');
        return;
      }

      if (!res.ok) throw new Error('Failed to load applications');

      const apps = await res.json();
      renderPending(apps);
    } catch (err) {
      console.error('[Terrarove admin] pending load error:', err);
      pendingList.innerHTML =
        '<p style="color:var(--text-soft);">⚠️ Could not load filings. Refresh and try again.</p>';
    }
  }

  function renderPending(apps) {
    if (!Array.isArray(apps) || apps.length === 0) {
      pendingList.innerHTML =
        '<p style="color:var(--text-soft);">🌿 No filings are waiting. When someone applies, their country will show up here.</p>';
      return;
    }

    // Sort newest first
    const sorted = apps.slice().sort(function (a, b) {
      return new Date(b.submittedAt || 0) - new Date(a.submittedAt || 0);
    });

    pendingList.innerHTML = sorted
      .map(function (a) {
        const handle = instagramHandle(a.instagram);
        const dateStr = fmtDate(a.submittedAt);
        const meta = (handle ? '@' + escapeHtml(handle) + ' · ' : '') + 'filed ' + dateStr;

        return (
          '<div class="app-row" data-id="' +
          escapeHtml(a.id) +
          '">' +
          '<img class="app-flag" src="' +
          escapeHtml(a.flag) +
          '" alt="Flag for ' +
          escapeHtml(a.name) +
          '" loading="lazy">' +
          '<div class="app-info">' +
          '<div class="app-name">' +
          escapeHtml(a.name) +
          '</div>' +
          '<div class="app-sub">' +
          meta +
          '</div>' +
          '</div>' +
          '<div class="app-actions">' +
          '<button class="btn btn-small btn-approve" data-action="approve" data-id="' +
          escapeHtml(a.id) +
          '">✓ Approve</button>' +
          '<button class="btn btn-small btn-reject" data-action="reject" data-id="' +
          escapeHtml(a.id) +
          '">✕ Reject</button>' +
          '</div>' +
          '</div>'
        );
      })
      .join('');

    pendingList.querySelectorAll('button[data-action]').forEach(function (btn) {
      btn.addEventListener('click', function () {
        decide(btn.dataset.id, btn.dataset.action, btn);
      });
    });
  }

  /* ----------------------------------------------------------
     3. DECISION — approve / reject
     ---------------------------------------------------------- */
  async function decide(id, action, btn) {
    const row = btn.closest('.app-row');
    if (row) {
      row.querySelectorAll('button').forEach(function (b) {
        b.disabled = true;
      });
    }
    btn.textContent = action === 'approve' ? '⏳ Approving…' : '⏳ Rejecting…';

    try {
      const res = await fetch('/api/admin/decision', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Admin-Code': adminCode
        },
        body: JSON.stringify({ id: id, action: action })
      });

      if (res.status === 401) {
        sessionStorage.removeItem(STORAGE_KEY);
        adminCode = '';
        gateWrap.style.display = 'block';
        chancelleryPanel.style.display = 'none';
        notify(gateError, 'error', 'Session expired — please re-enter the seal-code.');
        return;
      }

      if (!res.ok) throw new Error('Decision failed');

      // Fade out and reload
      if (row) {
        row.style.transition = 'opacity 0.25s ease, transform 0.25s ease';
        row.style.opacity = '0';
        row.style.transform = 'translateX(20px)';
        setTimeout(loadPending, 220);
      } else {
        loadPending();
      }
    } catch (err) {
      console.error('[Terrarove admin] decision error:', err);
      alert('⚠️ Could not save decision. Please try again.');
      if (row) {
        row.querySelectorAll('button').forEach(function (b) {
          b.disabled = false;
        });
      }
      btn.textContent = action === 'approve' ? '✓ Approve' : '✕ Reject';
    }
  }

  /* ----------------------------------------------------------
     4. MAP SWAP
     ---------------------------------------------------------- */
  async function loadMapThumb() {
    if (!currentMapThumb) return;
    try {
      const res = await fetch('/api/map', { headers: { Accept: 'application/json' } });
      if (!res.ok) return;
      const data = await res.json();
      if (data && data.path) currentMapThumb.src = data.path;
    } catch (e) { /* silent */ }
  }

  if (mapFile) {
    mapFile.addEventListener('change', async function () {
      const file = mapFile.files && mapFile.files[0];
      if (!file) return;

      if (!file.type.startsWith('image/')) {
        alert('🚫 Please choose an image file.');
        mapFile.value = '';
        return;
      }

      if (file.size > 4 * 1024 * 1024) {
        alert('📦 That map is larger than 4 MB — please choose a smaller file.');
        mapFile.value = '';
        return;
      }

      const formData = new FormData();
      formData.append('map', file);

      try {
        const res = await fetch('/api/admin/map', {
          method: 'POST',
          headers: { 'X-Admin-Code': adminCode },
          body: formData
        });

        if (res.status === 401) {
          sessionStorage.removeItem(STORAGE_KEY);
          adminCode = '';
          gateWrap.style.display = 'block';
          chancelleryPanel.style.display = 'none';
          notify(gateError, 'error', 'Session expired — please re-enter the seal-code.');
          return;
        }

        const data = await res.json().catch(function () { return {}; });
        if (!res.ok) throw new Error(data.error || 'Upload failed');

        if (data.path && currentMapThumb) {
          currentMapThumb.src = data.path + '?t=' + Date.now(); // bust cache
        }
        notify(mapConfirmNote, 'success', '✅ The atlas has been updated.');
      } catch (err) {
        console.error('[Terrarove admin] map upload error:', err);
        alert('⚠️ Map upload failed. Please try again.');
      } finally {
        mapFile.value = '';
      }
    });
  }

  /* ----------------------------------------------------------
     5. INIT
     ---------------------------------------------------------- */
  function init() {
    initRipple();

    // Auto-unlock if we still have a session code
    if (adminCode) {
      tryUnlock(adminCode);
    }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();