import os
import json
import uuid
from datetime import datetime
from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, 'data')
FLAGS_DIR = os.path.join(BASE_DIR, 'static', 'flags')
MAPS_DIR = os.path.join(BASE_DIR, 'static', 'maps')

NATIONS_FILE = os.path.join(DATA_DIR, 'nations.json')
APPS_FILE = os.path.join(DATA_DIR, 'applications.json')
MAP_FILE = os.path.join(DATA_DIR, 'map.json')

ADMIN_CODE = "TERRAROVE-1904"
ALLOWED_EXT = {'png', 'jpg', 'jpeg', 'webp', 'gif'}

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(FLAGS_DIR, exist_ok=True)
os.makedirs(MAPS_DIR, exist_ok=True)


def read_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return default


def write_json(path, data):
    with open(path, 'w', encoding='utf-8') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)


def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXT


def seed_if_empty():
    if read_json(NATIONS_FILE, None) is None:
        write_json(NATIONS_FILE, [])
    if read_json(APPS_FILE, None) is None:
        write_json(APPS_FILE, [])
    if read_json(MAP_FILE, None) is None:
        write_json(MAP_FILE, {"path": "/static/maps/terrarove_map.jpg"})


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/terms')
def terms():
    return render_template('terms.html')


@app.route('/admin')
def admin():
    return render_template('admin.html')


@app.route('/api/nations', methods=['GET'])
def get_nations():
    nations = read_json(NATIONS_FILE, [])
    nations.sort(key=lambda n: n.get('registryNo', 0))
    return jsonify(nations)


@app.route('/api/map', methods=['GET'])
def get_map():
    return jsonify(read_json(MAP_FILE, {"path": "/static/maps/terrarove_map.jpg"}))


@app.route('/api/apply', methods=['POST'])
def apply_nation():
    name = (request.form.get('name') or '').strip()
    instagram = (request.form.get('instagram') or '').strip()
    accepted_terms = (request.form.get('terms') or '').strip().lower()

    if not name:
        return jsonify({"error": "Country name is required"}), 400
    if accepted_terms not in ('true', 'on', '1', 'yes'):
        return jsonify({"error": "You must agree to the Terms of Service"}), 400
    if 'flag' not in request.files or request.files['flag'].filename == '':
        return jsonify({"error": "Flag image is required"}), 400

    file = request.files['flag']
    if not allowed_file(file.filename):
        return jsonify({"error": "Only image files are allowed"}), 400

    temp_id = uuid.uuid4().hex[:10]
    ext = file.filename.rsplit('.', 1)[1].lower()
    temp_filename = f"pending_{temp_id}.{ext}"
    temp_path = os.path.join(FLAGS_DIR, temp_filename)
    file.save(temp_path)

    applications = read_json(APPS_FILE, [])
    applications.append({
        "id": f"app-{temp_id}",
        "name": name,
        "flag": f"/static/flags/{temp_filename}",
        "instagram": instagram,
        "submittedAt": datetime.utcnow().isoformat(),
        "termsAccepted": True,
    })
    write_json(APPS_FILE, applications)

    return jsonify({
        "success": True,
        "message": "Your filing has been received. The Chancellery will review it before it joins the Register."
    })


@app.route('/api/admin/verify', methods=['POST'])
def verify_admin():
    code = (request.json or {}).get('code', '').strip()
    if code == ADMIN_CODE:
        return jsonify({"success": True})
    return jsonify({"success": False, "error": "Invalid seal-code"}), 401


@app.route('/api/admin/applications', methods=['GET'])
def admin_applications():
    if request.headers.get('X-Admin-Code') != ADMIN_CODE:
        return jsonify({"error": "Unauthorized"}), 401
    return jsonify(read_json(APPS_FILE, []))


@app.route('/api/admin/decision', methods=['POST'])
def admin_decision():
    if request.headers.get('X-Admin-Code') != ADMIN_CODE:
        return jsonify({"error": "Unauthorized"}), 401

    body = request.json or {}
    app_id = body.get('id')
    action = body.get('action')

    if action not in ('approve', 'reject'):
        return jsonify({"error": "Invalid action"}), 400

    applications = read_json(APPS_FILE, [])
    target = next((a for a in applications if a['id'] == app_id), None)
    if not target:
        return jsonify({"error": "Application not found"}), 404

    if action == 'approve':
        nations = read_json(NATIONS_FILE, [])
        next_no = max((n.get('registryNo', 0) for n in nations), default=0) + 1

        old_path = os.path.join(BASE_DIR, target['flag'].lstrip('/'))
        slug = ''.join(c if c.isalnum() else '-' for c in target['name'].lower()).strip('-') or f"nation-{next_no}"
        ext = target['flag'].rsplit('.', 1)[1]
        new_filename = f"{slug}-{next_no}.{ext}"
        new_path = os.path.join(FLAGS_DIR, new_filename)

        new_flag_url = target['flag']
        if os.path.exists(old_path):
            os.rename(old_path, new_path)
            new_flag_url = f"/static/flags/{new_filename}"

        nations.append({
            "id": target['id'],
            "name": target['name'],
            "flag": new_flag_url,
            "instagram": target.get('instagram', ''),
            "registryNo": next_no,
            "recognizedAt": datetime.utcnow().isoformat()
        })
        write_json(NATIONS_FILE, nations)
    else:
        flag_path = os.path.join(BASE_DIR, target['flag'].lstrip('/'))
        if os.path.exists(flag_path):
            try:
                os.remove(flag_path)
            except OSError:
                pass

    applications = [a for a in applications if a['id'] != app_id]
    write_json(APPS_FILE, applications)

    return jsonify({"success": True})


@app.route('/api/admin/map', methods=['POST'])
def admin_map():
    if request.headers.get('X-Admin-Code') != ADMIN_CODE:
        return jsonify({"error": "Unauthorized"}), 401

    if 'map' not in request.files:
        return jsonify({"error": "No map file"}), 400

    file = request.files['map']
    if file.filename == '' or not allowed_file(file.filename):
        return jsonify({"error": "Invalid file"}), 400

    ext = file.filename.rsplit('.', 1)[1].lower()
    filename = f"terrarove_map.{ext}"
    filepath = os.path.join(MAPS_DIR, filename)
    file.save(filepath)

    write_json(MAP_FILE, {"path": f"/static/maps/{filename}"})
    return jsonify({"success": True, "path": f"/static/maps/{filename}"})


seed_if_empty()

if __name__ == '__main__':
    app.run(debug=False)